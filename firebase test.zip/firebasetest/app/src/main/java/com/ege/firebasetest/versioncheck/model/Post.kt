package com.ege.firebasetest.versioncheck.model

data class Post(var title: String? = "",
                var body: String? = "")